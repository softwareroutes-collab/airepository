export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      categories: {
        Row: {
          id: string
          name: string
          slug: string
          description: string | null
          icon: string | null
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          slug: string
          description?: string | null
          icon?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          description?: string | null
          icon?: string | null
          created_at?: string
        }
      }
      tools: {
        Row: {
          id: string
          name: string
          slug: string
          category_id: string | null
          description: string | null
          pricing: Json
          logo_url: string | null
          website_url: string | null
          affiliate_url: string | null
          tags: string[]
          summary: string | null
          seo_description: string | null
          status: string
          view_count: number
          click_count: number
          is_sponsored: boolean
          featured_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          slug: string
          category_id?: string | null
          description?: string | null
          pricing?: Json
          logo_url?: string | null
          website_url?: string | null
          affiliate_url?: string | null
          tags?: string[]
          summary?: string | null
          seo_description?: string | null
          status?: string
          view_count?: number
          click_count?: number
          is_sponsored?: boolean
          featured_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          category_id?: string | null
          description?: string | null
          pricing?: Json
          logo_url?: string | null
          website_url?: string | null
          affiliate_url?: string | null
          tags?: string[]
          summary?: string | null
          seo_description?: string | null
          status?: string
          view_count?: number
          click_count?: number
          is_sponsored?: boolean
          featured_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      favorites: {
        Row: {
          id: string
          user_id: string
          tool_id: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          tool_id: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          tool_id?: string
          created_at?: string
        }
      }
      user_profiles: {
        Row: {
          id: string
          role: string
          subscription_tier: string
          stripe_customer_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          role?: string
          subscription_tier?: string
          stripe_customer_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          role?: string
          subscription_tier?: string
          stripe_customer_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
