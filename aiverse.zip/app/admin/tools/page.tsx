'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Check, X, Edit, Trash2, Plus } from 'lucide-react'

interface Tool {
  id: string
  name: string
  slug: string
  description: string
  status: string
  view_count: number
  click_count: number
  created_at: string
  is_sponsored: boolean
}

export default function AdminToolsPage() {
  const [tools, setTools] = useState<Tool[]>([])
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState(true)
  const supabase = createClient()
  const router = useRouter()

  useEffect(() => {
    checkAdmin()
  }, [])

  useEffect(() => {
    if (!loading) loadTools()
  }, [filter, loading])

  async function checkAdmin() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (!profile || profile.role !== 'admin') {
      router.push('/dashboard')
      return
    }

    setLoading(false)
  }

  async function loadTools() {
    let query = supabase
      .from('tools')
      .select('*')
      .order('created_at', { ascending: false })

    if (filter !== 'all') {
      query = query.eq('status', filter)
    }

    const { data } = await query
    if (data) setTools(data)
  }

  async function approveTool(toolId: string) {
    await supabase
      .from('tools')
      .update({ status: 'approved' })
      .eq('id', toolId)
    
    loadTools()
  }

  async function rejectTool(toolId: string) {
    if (!confirm('Reject this tool?')) return

    await supabase
      .from('tools')
      .update({ status: 'rejected' })
      .eq('id', toolId)
    
    loadTools()
  }

  async function deleteTool(toolId: string) {
    if (!confirm('Permanently delete this tool? This cannot be undone.')) return

    await supabase
      .from('tools')
      .delete()
      .eq('id', toolId)
    
    loadTools()
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 py-8">
          <Link href="/admin" className="text-purple-100 hover:text-white mb-4 inline-block">
            ← Back to Admin
          </Link>
          <h1 className="text-4xl font-bold mb-2">Manage Tools</h1>
          <p className="text-purple-100">Add, edit, approve, or remove AI tools</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex space-x-4">
              <button
                onClick={() => setFilter('all')}
                className={`px-4 py-2 rounded-lg font-semibold transition ${
                  filter === 'all'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                All Tools
              </button>
              <button
                onClick={() => setFilter('pending')}
                className={`px-4 py-2 rounded-lg font-semibold transition ${
                  filter === 'pending'
                    ? 'bg-orange-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Pending
              </button>
              <button
                onClick={() => setFilter('approved')}
                className={`px-4 py-2 rounded-lg font-semibold transition ${
                  filter === 'approved'
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Approved
              </button>
              <button
                onClick={() => setFilter('rejected')}
                className={`px-4 py-2 rounded-lg font-semibold transition ${
                  filter === 'rejected'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Rejected
              </button>
            </div>

            <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center">
              <Plus className="h-5 w-5 mr-2" />
              Add Tool
            </button>
          </div>
        </div>

        {/* Tools Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tool</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Views</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Clicks</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sponsored</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {tools.map((tool) => (
                <tr key={tool.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div>
                      <div className="font-semibold text-gray-900">{tool.name}</div>
                      <div className="text-sm text-gray-500 truncate max-w-md">{tool.description}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      tool.status === 'approved'
                        ? 'bg-green-100 text-green-800'
                        : tool.status === 'pending'
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {tool.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-900">{tool.view_count}</td>
                  <td className="px-6 py-4 text-gray-900">{tool.click_count}</td>
                  <td className="px-6 py-4">
                    {tool.is_sponsored ? (
                      <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">Yes</span>
                    ) : (
                      <span className="text-gray-400">No</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex space-x-2">
                      {tool.status === 'pending' && (
                        <>
                          <button
                            onClick={() => approveTool(tool.id)}
                            className="p-2 text-green-600 hover:bg-green-50 rounded transition"
                            title="Approve"
                          >
                            <Check className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => rejectTool(tool.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded transition"
                            title="Reject"
                          >
                            <X className="h-5 w-5" />
                          </button>
                        </>
                      )}
                      <button
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded transition"
                        title="Edit"
                      >
                        <Edit className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => deleteTool(tool.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded transition"
                        title="Delete"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {tools.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No tools found with status: {filter}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
