'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Play, Clock, CheckCircle, XCircle, Activity } from 'lucide-react'

interface ScrapingLog {
  id: string
  source: string
  tools_found: number
  tools_added: number
  duplicates_skipped: number
  status: string
  error_message: string | null
  run_at: string
}

export default function ScrapingControlPage() {
  const [logs, setLogs] = useState<ScrapingLog[]>([])
  const [running, setRunning] = useState(false)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()
  const router = useRouter()

  useEffect(() => {
    checkAdminAndLoad()
  }, [])

  async function checkAdminAndLoad() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (!profile || profile.role !== 'admin') {
      router.push('/dashboard')
      return
    }

    await loadLogs()
    setLoading(false)
  }

  async function loadLogs() {
    const { data } = await supabase
      .from('scraping_logs')
      .select('*')
      .order('run_at', { ascending: false })
      .limit(20)

    if (data) setLogs(data)
  }

  async function triggerScraping() {
    if (!confirm('Manually trigger tool discovery? This may take a few minutes.')) return

    setRunning(true)

    try {
      const { data, error } = await supabase.functions.invoke('scrape-tools', {
        body: {}
      })

      if (error) throw error

      alert(data?.data?.summary?.message || 'Scraping completed successfully!')
      await loadLogs()
    } catch (error: any) {
      alert('Error during scraping: ' + error.message)
    } finally {
      setRunning(false)
    }
  }

  function formatDate(dateString: string) {
    return new Date(dateString).toLocaleString()
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 py-8">
          <Link href="/admin" className="text-purple-100 hover:text-white mb-4 inline-block">
            ← Back to Admin
          </Link>
          <h1 className="text-4xl font-bold mb-2">Scraping Control</h1>
          <p className="text-purple-100">Manage automated AI tool discovery</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Control Panel */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-2xl font-bold mb-4">Manual Trigger</h2>
          <p className="text-gray-600 mb-6">
            Click the button below to manually trigger the tool discovery process. The automated system runs daily at 2:00 AM UTC.
          </p>

          <button
            onClick={triggerScraping}
            disabled={running}
            className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition disabled:opacity-50 flex items-center"
          >
            {running ? (
              <>
                <Clock className="h-5 w-5 mr-2 animate-spin" />
                Running...
              </>
            ) : (
              <>
                <Play className="h-5 w-5 mr-2" />
                Run Discovery Now
              </>
            )}
          </button>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h3 className="font-semibold text-blue-900 mb-2">How it works:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
              <li>Scans multiple sources for new AI tools</li>
              <li>Uses OpenRouter AI for deduplication and categorization</li>
              <li>Generates marketing summaries and SEO descriptions</li>
              <li>New tools added with "pending" status for your review</li>
              <li>Results logged below for tracking</li>
            </ul>
          </div>
        </div>

        {/* Scraping Logs */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center mb-6">
            <Activity className="h-6 w-6 text-purple-600 mr-2" />
            <h2 className="text-2xl font-bold">Scraping History</h2>
          </div>

          <div className="space-y-4">
            {logs.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                No scraping logs yet. Run the discovery process to see results here.
              </div>
            ) : (
              logs.map((log) => (
                <div
                  key={log.id}
                  className={`border rounded-lg p-4 ${
                    log.status === 'completed'
                      ? 'border-green-200 bg-green-50'
                      : log.status === 'failed'
                      ? 'border-red-200 bg-red-50'
                      : 'border-yellow-200 bg-yellow-50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        {log.status === 'completed' ? (
                          <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                        ) : log.status === 'failed' ? (
                          <XCircle className="h-5 w-5 text-red-600 mr-2" />
                        ) : (
                          <Clock className="h-5 w-5 text-yellow-600 mr-2" />
                        )}
                        <span className="font-semibold capitalize">{log.status}</span>
                        <span className="text-gray-500 text-sm ml-4">
                          {formatDate(log.run_at)}
                        </span>
                      </div>

                      <div className="grid grid-cols-4 gap-4 mb-2">
                        <div>
                          <div className="text-xs text-gray-500">Found</div>
                          <div className="text-lg font-bold">{log.tools_found}</div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-500">Added</div>
                          <div className="text-lg font-bold text-green-600">{log.tools_added}</div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-500">Duplicates</div>
                          <div className="text-lg font-bold text-gray-600">{log.duplicates_skipped}</div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-500">Source</div>
                          <div className="text-sm font-medium">{log.source}</div>
                        </div>
                      </div>

                      {log.error_message && (
                        <div className="mt-2 p-3 bg-red-100 rounded text-sm text-red-800">
                          <strong>Error:</strong> {log.error_message}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Cron Job Info */}
        <div className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg shadow p-6 mt-6 text-white">
          <h2 className="text-2xl font-bold mb-2">Automated Schedule</h2>
          <p className="text-purple-100 mb-4">
            The tool discovery process runs automatically every day at 2:00 AM UTC. You can also trigger it manually above.
          </p>
          <div className="flex items-center space-x-4">
            <div className="px-4 py-2 bg-white bg-opacity-20 rounded-lg">
              <div className="text-xs text-purple-200">Schedule</div>
              <div className="font-semibold">Daily at 2:00 AM UTC</div>
            </div>
            <div className="px-4 py-2 bg-white bg-opacity-20 rounded-lg">
              <div className="text-xs text-purple-200">Status</div>
              <div className="font-semibold">Active</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
