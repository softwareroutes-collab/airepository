'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Package, Settings, Activity, Users, Database, BarChart3 } from 'lucide-react'

export default function AdminPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [stats, setStats] = useState({
    totalTools: 0,
    pendingTools: 0,
    totalUsers: 0,
    totalCategories: 0
  })
  const [loading, setLoading] = useState(true)
  const supabase = createClient()
  const router = useRouter()

  useEffect(() => {
    checkAdmin()
  }, [])

  async function checkAdmin() {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      router.push('/login')
      return
    }

    setUser(user)

    // Check if user is admin
    const { data: profileData } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (!profileData || profileData.role !== 'admin') {
      alert('Access denied. Admin privileges required.')
      router.push('/dashboard')
      return
    }

    setProfile(profileData)
    await loadStats()
    setLoading(false)
  }

  async function loadStats() {
    // Total tools
    const { count: toolCount } = await supabase
      .from('tools')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'approved')

    // Pending tools
    const { count: pendingCount } = await supabase
      .from('tools')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending')

    // Total categories
    const { count: categoryCount } = await supabase
      .from('categories')
      .select('*', { count: 'exact', head: true })

    // Total users
    const { count: userCount } = await supabase
      .from('user_profiles')
      .select('*', { count: 'exact', head: true })

    setStats({
      totalTools: toolCount || 0,
      pendingTools: pendingCount || 0,
      totalUsers: userCount || 0,
      totalCategories: categoryCount || 0
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-2">Admin Panel</h1>
          <p className="text-purple-100">Manage your AI Tools Directory</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Tools</p>
                <p className="text-3xl font-bold">{stats.totalTools}</p>
              </div>
              <Package className="h-12 w-12 text-blue-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Pending Approval</p>
                <p className="text-3xl font-bold text-orange-600">{stats.pendingTools}</p>
              </div>
              <Activity className="h-12 w-12 text-orange-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Users</p>
                <p className="text-3xl font-bold">{stats.totalUsers}</p>
              </div>
              <Users className="h-12 w-12 text-green-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Categories</p>
                <p className="text-3xl font-bold">{stats.totalCategories}</p>
              </div>
              <Database className="h-12 w-12 text-purple-600" />
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link
            href="/admin/tools"
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group"
          >
            <Package className="h-10 w-10 text-blue-600 mb-4 group-hover:scale-110 transition" />
            <h3 className="font-semibold text-xl mb-2">Manage Tools</h3>
            <p className="text-gray-600">Add, edit, approve, or delete AI tools</p>
            {stats.pendingTools > 0 && (
              <span className="inline-block mt-3 px-3 py-1 bg-orange-100 text-orange-800 text-sm font-semibold rounded-full">
                {stats.pendingTools} pending
              </span>
            )}
          </Link>

          <Link
            href="/admin/openrouter"
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group"
          >
            <Settings className="h-10 w-10 text-purple-600 mb-4 group-hover:scale-110 transition" />
            <h3 className="font-semibold text-xl mb-2">OpenRouter Settings</h3>
            <p className="text-gray-600">Configure AI API keys and model settings</p>
          </Link>

          <Link
            href="/admin/scraping"
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group"
          >
            <Activity className="h-10 w-10 text-green-600 mb-4 group-hover:scale-110 transition" />
            <h3 className="font-semibold text-xl mb-2">Scraping Control</h3>
            <p className="text-gray-600">Manage automated tool discovery</p>
          </Link>

          <Link
            href="/admin/analytics"
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group"
          >
            <BarChart3 className="h-10 w-10 text-indigo-600 mb-4 group-hover:scale-110 transition" />
            <h3 className="font-semibold text-xl mb-2">Analytics</h3>
            <p className="text-gray-600">View platform analytics and insights</p>
          </Link>

          <Link
            href="/dashboard"
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group"
          >
            <Users className="h-10 w-10 text-cyan-600 mb-4 group-hover:scale-110 transition" />
            <h3 className="font-semibold text-xl mb-2">User Dashboard</h3>
            <p className="text-gray-600">Switch to user view</p>
          </Link>

          <div className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg shadow p-6 text-white">
            <Database className="h-10 w-10 mb-4" />
            <h3 className="font-semibold text-xl mb-2">Database Status</h3>
            <p className="text-purple-100">All systems operational</p>
            <a
              href="https://app.supabase.com/project/kxcfdfsdpribtjlyupmf"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block mt-3 px-4 py-2 bg-white text-purple-600 rounded-lg text-sm font-semibold hover:bg-gray-100 transition"
            >
              Open Supabase
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
