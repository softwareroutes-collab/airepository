'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { TrendingUp, Eye, MousePointerClick, DollarSign, Users } from 'lucide-react'

export default function AnalyticsPage() {
  const [stats, setStats] = useState({
    totalViews: 0,
    totalClicks: 0,
    totalRevenue: 0,
    conversionRate: 0,
    topTools: [] as any[]
  })
  const [loading, setLoading] = useState(true)
  const supabase = createClient()
  const router = useRouter()

  useEffect(() => {
    checkAdminAndLoad()
  }, [])

  async function checkAdminAndLoad() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (!profile || profile.role !== 'admin') {
      router.push('/dashboard')
      return
    }

    await loadAnalytics()
    setLoading(false)
  }

  async function loadAnalytics() {
    // Get total views and clicks
    const { data: tools } = await supabase
      .from('tools')
      .select('view_count, click_count, name, slug')
      .eq('status', 'approved')

    if (tools) {
      const totalViews = tools.reduce((sum, t) => sum + t.view_count, 0)
      const totalClicks = tools.reduce((sum, t) => sum + t.click_count, 0)
      const conversionRate = totalViews > 0 ? (totalClicks / totalViews) * 100 : 0

      // Get top tools by views
      const topTools = [...tools]
        .sort((a, b) => b.view_count - a.view_count)
        .slice(0, 10)

      setStats({
        totalViews,
        totalClicks,
        totalRevenue: 0, // Calculated from affiliate_stats
        conversionRate,
        topTools
      })
    }

    // Get revenue from affiliate stats
    const { data: affiliateStats } = await supabase
      .from('affiliate_stats')
      .select('revenue')

    if (affiliateStats) {
      const totalRevenue = affiliateStats.reduce((sum, stat) => sum + (stat.revenue || 0), 0)
      setStats(prev => ({ ...prev, totalRevenue }))
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 py-8">
          <Link href="/admin" className="text-purple-100 hover:text-white mb-4 inline-block">
            ← Back to Admin
          </Link>
          <h1 className="text-4xl font-bold mb-2">Analytics Dashboard</h1>
          <p className="text-purple-100">Platform performance and insights</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <Eye className="h-8 w-8 text-blue-600" />
              <TrendingUp className="h-5 w-5 text-green-500" />
            </div>
            <div className="text-3xl font-bold mb-1">{stats.totalViews.toLocaleString()}</div>
            <div className="text-gray-600 text-sm">Total Views</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <MousePointerClick className="h-8 w-8 text-green-600" />
              <TrendingUp className="h-5 w-5 text-green-500" />
            </div>
            <div className="text-3xl font-bold mb-1">{stats.totalClicks.toLocaleString()}</div>
            <div className="text-gray-600 text-sm">Total Clicks</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <DollarSign className="h-8 w-8 text-purple-600" />
              <TrendingUp className="h-5 w-5 text-green-500" />
            </div>
            <div className="text-3xl font-bold mb-1">${stats.totalRevenue.toFixed(2)}</div>
            <div className="text-gray-600 text-sm">Total Revenue</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <Users className="h-8 w-8 text-orange-600" />
            </div>
            <div className="text-3xl font-bold mb-1">{stats.conversionRate.toFixed(2)}%</div>
            <div className="text-gray-600 text-sm">Conversion Rate</div>
          </div>
        </div>

        {/* Top Performing Tools */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-2xl font-bold mb-6">Top Performing Tools</h2>
          <div className="space-y-4">
            {stats.topTools.map((tool, index) => (
              <div key={tool.slug} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <div className="font-semibold">{tool.name}</div>
                    <Link href={`/tools/${tool.slug}`} className="text-sm text-blue-600 hover:text-blue-700">
                      View Tool →
                    </Link>
                  </div>
                </div>
                <div className="flex items-center space-x-6 text-sm">
                  <div className="text-center">
                    <div className="font-bold text-lg">{tool.view_count.toLocaleString()}</div>
                    <div className="text-gray-500">Views</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-lg">{tool.click_count.toLocaleString()}</div>
                    <div className="text-gray-500">Clicks</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-lg text-green-600">
                      {tool.view_count > 0 ? ((tool.click_count / tool.view_count) * 100).toFixed(1) : 0}%
                    </div>
                    <div className="text-gray-500">CTR</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg shadow p-6 text-white">
            <h3 className="text-xl font-bold mb-2">API Usage Logs</h3>
            <p className="text-blue-100 mb-4">View detailed OpenRouter API usage and costs</p>
            <a
              href="https://app.supabase.com/project/kxcfdfsdpribtjlyupmf/editor"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-6 py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              Open Supabase
            </a>
          </div>

          <div className="bg-gradient-to-br from-green-600 to-teal-600 rounded-lg shadow p-6 text-white">
            <h3 className="text-xl font-bold mb-2">Affiliate Stats</h3>
            <p className="text-green-100 mb-4">Track affiliate clicks and conversions</p>
            <a
              href="https://app.supabase.com/project/kxcfdfsdpribtjlyupmf/editor"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-6 py-3 bg-white text-green-600 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              View Database
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
