'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Save, Key, Settings as SettingsIcon, Activity } from 'lucide-react'

export default function OpenRouterSettingsPage() {
  const [apiKey, setApiKey] = useState('')
  const [isActive, setIsActive] = useState(true)
  const [models, setModels] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const supabase = createClient()
  const router = useRouter()

  useEffect(() => {
    checkAdminAndLoad()
  }, [])

  async function checkAdminAndLoad() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (!profile || profile.role !== 'admin') {
      router.push('/dashboard')
      return
    }

    await loadSettings()
    setLoading(false)
  }

  async function loadSettings() {
    // Load OpenRouter settings
    const { data: settings } = await supabase
      .from('openrouter_settings')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (settings) {
      setApiKey(settings.api_key === 'YOUR_OPENROUTER_API_KEY_HERE' ? '' : settings.api_key)
      setIsActive(settings.is_active)
    }

    // Load model configurations
    const { data: modelData } = await supabase
      .from('model_configurations')
      .select('*')
      .order('task_type')

    if (modelData) setModels(modelData)
  }

  async function handleSaveSettings() {
    if (!apiKey.trim()) {
      alert('Please enter an API key')
      return
    }

    setSaving(true)

    try {
      // Update or insert OpenRouter settings
      const { data: existing } = await supabase
        .from('openrouter_settings')
        .select('id')
        .limit(1)
        .maybeSingle()

      if (existing) {
        await supabase
          .from('openrouter_settings')
          .update({
            api_key: apiKey,
            is_active: isActive,
            updated_at: new Date().toISOString()
          })
          .eq('id', existing.id)
      } else {
        await supabase
          .from('openrouter_settings')
          .insert({
            api_key: apiKey,
            is_active: isActive
          })
      }

      alert('Settings saved successfully!')
    } catch (error: any) {
      alert('Error saving settings: ' + error.message)
    } finally {
      setSaving(false)
    }
  }

  async function toggleModelActive(modelId: string, currentActive: boolean) {
    await supabase
      .from('model_configurations')
      .update({ is_active: !currentActive })
      .eq('id', modelId)

    loadSettings()
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 py-8">
          <Link href="/admin" className="text-purple-100 hover:text-white mb-4 inline-block">
            ← Back to Admin
          </Link>
          <h1 className="text-4xl font-bold mb-2">OpenRouter Settings</h1>
          <p className="text-purple-100">Configure AI API keys and model preferences</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* API Key Configuration */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="flex items-center mb-4">
            <Key className="h-6 w-6 text-purple-600 mr-2" />
            <h2 className="text-2xl font-bold">API Configuration</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                OpenRouter API Key
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-or-..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              <p className="mt-2 text-sm text-gray-500">
                Get your API key from <a href="https://openrouter.ai" target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:text-purple-700">OpenRouter.ai</a>
              </p>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
              />
              <label className="ml-2 text-sm text-gray-700">
                Enable OpenRouter API
              </label>
            </div>

            <button
              onClick={handleSaveSettings}
              disabled={saving}
              className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition disabled:opacity-50 flex items-center"
            >
              <Save className="h-5 w-5 mr-2" />
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </div>

        {/* Model Configurations */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center mb-4">
            <SettingsIcon className="h-6 w-6 text-purple-600 mr-2" />
            <h2 className="text-2xl font-bold">Model Configurations</h2>
          </div>

          <p className="text-gray-600 mb-6">
            Configure which AI models to use for each task type. Active models will be used for automated processing.
          </p>

          <div className="space-y-4">
            {['deduplication', 'categorization', 'summarization', 'seo', 'recommendations'].map((taskType) => {
              const taskModels = models.filter(m => m.task_type === taskType)
              const activeModel = taskModels.find(m => m.is_active && !m.is_fallback)

              return (
                <div key={taskType} className="border rounded-lg p-4">
                  <h3 className="font-semibold text-lg capitalize mb-3">{taskType}</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {taskModels.map((model) => (
                      <div
                        key={model.id}
                        className={`border rounded-lg p-4 ${
                          model.is_active ? 'border-purple-600 bg-purple-50' : 'border-gray-200'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="font-medium">{model.model_name}</div>
                            <div className="text-xs text-gray-500">
                              {model.is_fallback ? 'Fallback Model' : 'Primary Model'}
                            </div>
                          </div>
                          <button
                            onClick={() => toggleModelActive(model.id, model.is_active)}
                            className={`px-3 py-1 rounded text-xs font-semibold ${
                              model.is_active
                                ? 'bg-green-100 text-green-800'
                                : 'bg-gray-100 text-gray-600'
                            }`}
                          >
                            {model.is_active ? 'Active' : 'Inactive'}
                          </button>
                        </div>
                        <div className="text-sm space-y-1">
                          <div className="flex justify-between text-gray-600">
                            <span>Temperature:</span>
                            <span className="font-medium">{model.temperature}</span>
                          </div>
                          <div className="flex justify-between text-gray-600">
                            <span>Max Tokens:</span>
                            <span className="font-medium">{model.max_tokens}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Usage Stats */}
        <div className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg shadow p-6 mt-6 text-white">
          <div className="flex items-center mb-4">
            <Activity className="h-6 w-6 mr-2" />
            <h2 className="text-2xl font-bold">API Usage</h2>
          </div>
          <p className="text-purple-100 mb-4">
            Monitor your OpenRouter API usage in the Supabase dashboard under the api_usage_logs table.
          </p>
          <a
            href="https://app.supabase.com/project/kxcfdfsdpribtjlyupmf/editor"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-6 py-3 bg-white text-purple-600 rounded-lg font-semibold hover:bg-gray-100 transition"
          >
            View in Supabase
          </a>
        </div>
      </div>
    </div>
  )
}
