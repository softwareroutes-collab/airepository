'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Heart, Book, Settings, BarChart3, LogOut } from 'lucide-react'

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [favoriteCount, setFavoriteCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()
  const router = useRouter()

  useEffect(() => {
    loadUser()
  }, [])

  async function loadUser() {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      router.push('/login')
      return
    }

    setUser(user)

    // Load profile
    const { data: profileData } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (profileData) {
      setProfile(profileData)
    } else {
      // Create profile if doesn't exist
      await supabase.from('user_profiles').insert({
        id: user.id,
        role: 'user',
        subscription_tier: 'free'
      })
    }

    // Load favorites count
    const { count } = await supabase
      .from('favorites')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)

    setFavoriteCount(count || 0)
    setLoading(false)
  }

  async function handleSignOut() {
    await supabase.auth.signOut()
    router.push('/')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user?.email}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Subscription</p>
                <p className="text-2xl font-bold capitalize">{profile?.subscription_tier || 'Free'}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Favorites</p>
                <p className="text-2xl font-bold">{favoriteCount}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Heart className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Account Type</p>
                <p className="text-2xl font-bold capitalize">{profile?.role || 'User'}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Settings className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Link
            href="/dashboard/favorites"
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group"
          >
            <Heart className="h-8 w-8 text-red-600 mb-3 group-hover:scale-110 transition" />
            <h3 className="font-semibold text-lg mb-1">My Favorites</h3>
            <p className="text-gray-600 text-sm">View your saved tools</p>
          </Link>

          <Link
            href="/tools"
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group"
          >
            <Book className="h-8 w-8 text-blue-600 mb-3 group-hover:scale-110 transition" />
            <h3 className="font-semibold text-lg mb-1">Browse Tools</h3>
            <p className="text-gray-600 text-sm">Discover new AI tools</p>
          </Link>

          <Link
            href="/dashboard/settings"
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group"
          >
            <Settings className="h-8 w-8 text-gray-600 mb-3 group-hover:scale-110 transition" />
            <h3 className="font-semibold text-lg mb-1">Settings</h3>
            <p className="text-gray-600 text-sm">Manage your account</p>
          </Link>

          {profile?.role === 'admin' && (
            <Link
              href="/admin"
              className="bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-lg shadow p-6 hover:shadow-lg transition group"
            >
              <BarChart3 className="h-8 w-8 mb-3 group-hover:scale-110 transition" />
              <h3 className="font-semibold text-lg mb-1">Admin Panel</h3>
              <p className="text-purple-100 text-sm">Manage platform</p>
            </Link>
          )}
        </div>

        {/* Upgrade CTA for free users */}
        {profile?.subscription_tier === 'free' && (
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-2">Upgrade to Premium</h2>
            <p className="text-blue-100 mb-4">
              Get access to premium tutorials, AI recommendations, tool comparisons, and more!
            </p>
            <Link
              href="/pricing"
              className="inline-block px-6 py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              View Plans
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
