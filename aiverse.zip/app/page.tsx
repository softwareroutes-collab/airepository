'use client'

import { useState, useEffect } from 'react'
import { Search, TrendingUp, Clock, Star, Eye, MousePointerClick, ArrowRight } from 'lucide-react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase-client'
import { formatNumber } from '@/lib/utils'

interface Tool {
  id: string
  name: string
  slug: string
  description: string
  logo_url: string | null
  tags: string[]
  view_count: number
  click_count: number
  is_sponsored: boolean
  category_id: string
  created_at: string
}

interface Category {
  id: string
  name: string
  slug: string
  icon: string | null
}

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [trendingTools, setTrendingTools] = useState<Tool[]>([])
  const [popularTools, setPopularTools] = useState<Tool[]>([])
  const [newTools, setNewTools] = useState<Tool[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    setLoading(true)
    try {
      // Load categories
      const { data: categoriesData } = await supabase
        .from('categories')
        .select('*')
        .order('name')

      if (categoriesData) setCategories(categoriesData)

      // Load trending tools (high recent activity)
      const { data: trendingData } = await supabase
        .from('tools')
        .select('*')
        .eq('status', 'approved')
        .order('view_count', { ascending: false })
        .limit(6)

      if (trendingData) setTrendingTools(trendingData)

      // Load popular tools (high total views)
      const { data: popularData } = await supabase
        .from('tools')
        .select('*')
        .eq('status', 'approved')
        .order('view_count', { ascending: false })
        .limit(6)

      if (popularData) setPopularTools(popularData)

      // Load new tools
      const { data: newData } = await supabase
        .from('tools')
        .select('*')
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .limit(6)

      if (newData) setNewTools(newData)

    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault()
    if (searchQuery.trim()) {
      window.location.href = `/tools?search=${encodeURIComponent(searchQuery)}`
    }
  }

  function ToolCard({ tool }: { tool: Tool }) {
    return (
      <Link href={`/tools/${tool.slug}`} className="block">
        <div className="bg-white border rounded-lg p-6 hover:shadow-lg transition-all hover:border-blue-300">
          {tool.is_sponsored && (
            <span className="inline-block px-2 py-1 bg-yellow-100 text-yellow-800 text-xs font-semibold rounded mb-2">
              SPONSORED
            </span>
          )}
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-2xl flex-shrink-0">
              {tool.logo_url ? (
                <img src={tool.logo_url} alt={tool.name} className="w-full h-full object-cover rounded-lg" />
              ) : (
                tool.name.charAt(0)
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-lg text-gray-900 truncate">{tool.name}</h3>
              <p className="text-gray-600 text-sm mt-1 line-clamp-2">{tool.description}</p>
              <div className="flex flex-wrap gap-2 mt-3">
                {tool.tags.slice(0, 3).map((tag) => (
                  <span key={tag} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex items-center space-x-4 mt-3 text-xs text-gray-500">
                <span className="flex items-center">
                  <Eye className="h-3 w-3 mr-1" />
                  {formatNumber(tool.view_count)}
                </span>
                <span className="flex items-center">
                  <MousePointerClick className="h-3 w-3 mr-1" />
                  {formatNumber(tool.click_count)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </Link>
    )
  }

  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Discover the Best AI Tools
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Explore curated AI tools for every need. Updated daily with AI-powered discovery.
            </p>
            
            {/* Search Bar */}
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search for AI tools..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 rounded-full text-gray-900 text-lg focus:outline-none focus:ring-4 focus:ring-blue-300"
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition"
                >
                  Search
                </button>
              </div>
            </form>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 mt-12 max-w-2xl mx-auto">
              <div>
                <div className="text-4xl font-bold">{trendingTools.length + popularTools.length + newTools.length}+</div>
                <div className="text-blue-200">AI Tools</div>
              </div>
              <div>
                <div className="text-4xl font-bold">{categories.length}+</div>
                <div className="text-blue-200">Categories</div>
              </div>
              <div>
                <div className="text-4xl font-bold">Daily</div>
                <div className="text-blue-200">Updates</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Browse by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/categories/${category.slug}`}
              className="bg-white border rounded-lg p-6 hover:shadow-lg transition-all hover:border-blue-300 text-center"
            >
              <div className="text-4xl mb-3">{category.icon || '🤖'}</div>
              <h3 className="font-semibold">{category.name}</h3>
            </Link>
          ))}
        </div>
      </section>

      {/* Trending Tools */}
      <section className="container mx-auto px-4 py-16 bg-white rounded-lg my-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <TrendingUp className="h-8 w-8 text-orange-500" />
            <h2 className="text-3xl font-bold">Trending Tools</h2>
          </div>
          <Link href="/tools" className="flex items-center text-blue-600 hover:text-blue-700">
            View All <ArrowRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        {loading ? (
          <div className="text-center py-12">Loading...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trendingTools.map((tool) => (
              <ToolCard key={tool.id} tool={tool} />
            ))}
          </div>
        )}
      </section>

      {/* Popular Tools */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <Star className="h-8 w-8 text-yellow-500" />
            <h2 className="text-3xl font-bold">Most Popular</h2>
          </div>
          <Link href="/tools?sort=popular" className="flex items-center text-blue-600 hover:text-blue-700">
            View All <ArrowRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularTools.map((tool) => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      </section>

      {/* New Tools */}
      <section className="container mx-auto px-4 py-16 bg-white rounded-lg my-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <Clock className="h-8 w-8 text-green-500" />
            <h2 className="text-3xl font-bold">Newly Added</h2>
          </div>
          <Link href="/tools?sort=new" className="flex items-center text-blue-600 hover:text-blue-700">
            View All <ArrowRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {newTools.map((tool) => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-white text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Explore More?</h2>
          <p className="text-xl mb-8 text-blue-100">
            Sign up to save your favorite tools, access premium tutorials, and get personalized recommendations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/signup" 
              className="px-8 py-4 bg-white text-blue-600 rounded-full font-semibold hover:bg-gray-100 transition"
            >
              Get Started Free
            </Link>
            <Link 
              href="/pricing" 
              className="px-8 py-4 border-2 border-white rounded-full font-semibold hover:bg-white hover:text-blue-600 transition"
            >
              View Pricing
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
