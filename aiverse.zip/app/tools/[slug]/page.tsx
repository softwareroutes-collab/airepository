'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase-client'
import { formatNumber } from '@/lib/utils'
import { ExternalLink, Heart, Eye, MousePointerClick, Share2, ArrowLeft } from 'lucide-react'
import Link from 'next/link'

interface Tool {
  id: string
  name: string
  slug: string
  description: string
  summary: string | null
  seo_description: string | null
  logo_url: string | null
  website_url: string | null
  affiliate_url: string | null
  tags: string[]
  pricing: any
  view_count: number
  click_count: number
  is_sponsored: boolean
  category_id: string
  created_at: string
}

interface Recommendation {
  id: string
  name: string
  slug: string
  description: string
  logo_url: string | null
  tags: string[]
}

export default function ToolDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [tool, setTool] = useState<Tool | null>(null)
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [loading, setLoading] = useState(true)
  const [isFavorite, setIsFavorite] = useState(false)
  const [user, setUser] = useState<any>(null)
  const supabase = createClient()

  useEffect(() => {
    loadTool()
    loadUser()
  }, [params.slug])

  async function loadUser() {
    const { data: { user } } = await supabase.auth.getUser()
    setUser(user)

    if (user && tool) {
      // Check if tool is favorited
      const { data } = await supabase
        .from('favorites')
        .select('*')
        .eq('user_id', user.id)
        .eq('tool_id', tool.id)
        .maybeSingle()

      setIsFavorite(!!data)
    }
  }

  async function loadTool() {
    setLoading(true)
    try {
      const { data } = await supabase
        .from('tools')
        .select('*')
        .eq('slug', params.slug)
        .eq('status', 'approved')
        .maybeSingle()

      if (!data) {
        router.push('/tools')
        return
      }

      setTool(data)

      // Track view
      await supabase.functions.invoke('analytics-tracker', {
        body: {
          action: 'view',
          toolId: data.id
        }
      })

      // Load recommendations
      const { data: recsData } = await supabase.functions.invoke('get-recommendations', {
        body: {
          toolId: data.id,
          limit: 3
        }
      })

      if (recsData?.data?.recommendations) {
        setRecommendations(recsData.data.recommendations)
      }
    } catch (error) {
      console.error('Error loading tool:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleVisitSite() {
    if (!tool) return

    // Track click
    await supabase.functions.invoke('analytics-tracker', {
      body: {
        action: 'click',
        toolId: tool.id
      }
    })

    // Open affiliate or website URL
    const url = tool.affiliate_url || tool.website_url
    if (url) {
      window.open(url, '_blank')
    }
  }

  async function toggleFavorite() {
    if (!user) {
      router.push('/login')
      return
    }

    if (!tool) return

    if (isFavorite) {
      await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('tool_id', tool.id)
      setIsFavorite(false)
    } else {
      await supabase
        .from('favorites')
        .insert({
          user_id: user.id,
          tool_id: tool.id
        })
      setIsFavorite(true)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!tool) {
    return null
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-8">
          <Link href="/tools" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Tools
          </Link>

          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-6">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-4xl flex-shrink-0">
                {tool.logo_url ? (
                  <img src={tool.logo_url} alt={tool.name} className="w-full h-full object-cover rounded-lg" />
                ) : (
                  tool.name.charAt(0)
                )}
              </div>

              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h1 className="text-4xl font-bold text-gray-900">{tool.name}</h1>
                  {tool.is_sponsored && (
                    <span className="px-3 py-1 bg-yellow-100 text-yellow-800 text-sm font-semibold rounded">
                      SPONSORED
                    </span>
                  )}
                </div>
                <p className="text-xl text-gray-600 mb-4">{tool.description}</p>
                <div className="flex items-center space-x-6 text-sm text-gray-500">
                  <span className="flex items-center">
                    <Eye className="h-4 w-4 mr-1" />
                    {formatNumber(tool.view_count)} views
                  </span>
                  <span className="flex items-center">
                    <MousePointerClick className="h-4 w-4 mr-1" />
                    {formatNumber(tool.click_count)} clicks
                  </span>
                </div>
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={toggleFavorite}
                className={`px-4 py-2 border rounded-lg transition ${
                  isFavorite
                    ? 'bg-red-50 border-red-300 text-red-600'
                    : 'border-gray-300 hover:bg-gray-50'
                }`}
              >
                <Heart className={`h-5 w-5 ${isFavorite ? 'fill-current' : ''}`} />
              </button>
              <button
                onClick={handleVisitSite}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center"
              >
                <ExternalLink className="h-5 w-5 mr-2" />
                Visit Website
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Summary */}
            {tool.summary && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-2xl font-bold mb-4">About</h2>
                <p className="text-gray-700 leading-relaxed">{tool.summary}</p>
              </div>
            )}

            {/* Tags */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-2xl font-bold mb-4">Tags</h2>
              <div className="flex flex-wrap gap-2">
                {tool.tags.map((tag) => (
                  <span key={tag} className="px-4 py-2 bg-blue-50 text-blue-700 rounded-full text-sm font-medium">
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            {recommendations.length > 0 && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-2xl font-bold mb-4">You Might Also Like</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {recommendations.map((rec) => (
                    <Link
                      key={rec.id}
                      href={`/tools/${rec.slug}`}
                      className="border rounded-lg p-4 hover:border-blue-300 hover:shadow transition"
                    >
                      <div className="flex items-center space-x-3 mb-2">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold">
                          {rec.logo_url ? (
                            <img src={rec.logo_url} alt={rec.name} className="w-full h-full object-cover rounded-lg" />
                          ) : (
                            rec.name.charAt(0)
                          )}
                        </div>
                        <h3 className="font-semibold">{rec.name}</h3>
                      </div>
                      <p className="text-sm text-gray-600 line-clamp-2">{rec.description}</p>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Pricing */}
            {tool.pricing && typeof tool.pricing === 'object' && Object.keys(tool.pricing).length > 0 && (
              <div className="bg-white rounded-lg shadow p-6 mb-6">
                <h2 className="text-xl font-bold mb-4">Pricing</h2>
                <div className="space-y-3">
                  {tool.pricing.free && (
                    <div className="border-l-4 border-green-500 pl-3">
                      <div className="font-semibold">Free Tier</div>
                      <div className="text-sm text-gray-600">{tool.pricing.free}</div>
                    </div>
                  )}
                  {tool.pricing.paid && typeof tool.pricing.paid === 'object' && (
                    <>
                      {Object.entries(tool.pricing.paid).map(([tier, price]) => (
                        <div key={tier} className="border-l-4 border-blue-500 pl-3">
                          <div className="font-semibold">{tier}</div>
                          <div className="text-sm text-gray-600">{price as string}</div>
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </div>
            )}

            {/* CTA */}
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg shadow p-6 text-white">
              <h3 className="text-xl font-bold mb-2">Ready to try it?</h3>
              <p className="text-blue-100 mb-4">Click the button below to visit the official website</p>
              <button
                onClick={handleVisitSite}
                className="w-full px-6 py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100 transition flex items-center justify-center"
              >
                <ExternalLink className="h-5 w-5 mr-2" />
                Visit {tool.name}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
