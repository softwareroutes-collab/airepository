'use client'

import { useState, useEffect } from 'react'
import { Check, X } from 'lucide-react'
import { createClient } from '@/lib/supabase-client'
import { useRouter } from 'next/navigation'

export default function PricingPage() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState('')
  const supabase = createClient()
  const router = useRouter()

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user)
    })
  }, [])

  async function handleSubscribe(priceId: string) {
    if (!user) {
      router.push('/login')
      return
    }

    setLoading(priceId)

    try {
      const { data, error } = await supabase.functions.invoke('create-checkout-session', {
        body: {
          priceId,
          userId: user.id
        }
      })

      if (error) throw error

      if (data?.data?.url) {
        window.location.href = data.data.url
      }
    } catch (err: any) {
      alert('Error creating checkout session. Please ensure Stripe is configured.')
      console.error(err)
    } finally {
      setLoading('')
    }
  }

  const plans = [
    {
      name: 'Free',
      price: '$0',
      priceId: null,
      description: 'Perfect for exploring AI tools',
      features: [
        'Browse all AI tools',
        'Search and filter',
        'View tool details',
        'Community support',
      ],
      notIncluded: [
        'Save favorites',
        'Access tutorials',
        'Tool comparisons',
        'AI recommendations',
        'API access',
      ],
      cta: 'Current Plan',
      highlighted: false,
    },
    {
      name: 'Premium',
      price: '$10',
      period: '/month',
      priceId: 'price_premium', // Replace with actual Stripe price ID
      description: 'For professionals who want more',
      features: [
        'Everything in Free',
        'Save unlimited favorites',
        'Access premium tutorials',
        'Side-by-side tool comparison',
        'Personalized AI recommendations',
        'Priority support',
        'API access (1000 requests/month)',
        'Early access to new features',
      ],
      notIncluded: [],
      cta: 'Subscribe Now',
      highlighted: true,
    },
    {
      name: 'Enterprise',
      price: 'Custom',
      priceId: null,
      description: 'For teams and organizations',
      features: [
        'Everything in Premium',
        'Unlimited API access',
        'Custom integrations',
        'Dedicated account manager',
        'SLA guarantee',
        'Custom training',
        'White-label options',
        'Advanced analytics',
      ],
      notIncluded: [],
      cta: 'Contact Sales',
      highlighted: false,
    },
  ]

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl text-blue-100">
            Choose the plan that fits your needs. Upgrade or downgrade anytime.
          </p>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`bg-white rounded-lg shadow-lg overflow-hidden ${
                plan.highlighted ? 'ring-2 ring-blue-600 transform scale-105' : ''
              }`}
            >
              {plan.highlighted && (
                <div className="bg-blue-600 text-white text-center py-2 text-sm font-semibold">
                  MOST POPULAR
                </div>
              )}
              
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                
                <div className="mb-6">
                  <span className="text-5xl font-bold text-gray-900">{plan.price}</span>
                  {plan.period && <span className="text-gray-600">{plan.period}</span>}
                </div>

                <button
                  onClick={() => plan.priceId && handleSubscribe(plan.priceId)}
                  disabled={!plan.priceId || loading === plan.priceId}
                  className={`w-full py-3 rounded-lg font-semibold transition ${
                    plan.highlighted
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  } ${!plan.priceId ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  {loading === plan.priceId ? 'Processing...' : plan.cta}
                </button>

                <div className="mt-8 space-y-4">
                  {plan.features.map((feature) => (
                    <div key={feature} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                  {plan.notIncluded.map((feature) => (
                    <div key={feature} className="flex items-start opacity-50">
                      <X className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-500">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto mt-20">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold text-lg mb-2">Can I change plans later?</h3>
              <p className="text-gray-600">
                Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold text-lg mb-2">How does the API access work?</h3>
              <p className="text-gray-600">
                Premium users get access to our REST API with 1000 requests per month. Enterprise users get unlimited access.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold text-lg mb-2">What payment methods do you accept?</h3>
              <p className="text-gray-600">
                We accept all major credit cards through Stripe. Enterprise clients can arrange custom payment terms.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold text-lg mb-2">Is there a refund policy?</h3>
              <p className="text-gray-600">
                Yes, we offer a 14-day money-back guarantee for all new subscriptions. No questions asked.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="max-w-4xl mx-auto mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">Still have questions?</h2>
          <p className="text-xl text-blue-100 mb-6">
            Our team is here to help you find the perfect plan for your needs.
          </p>
          <a
            href="mailto:support@aiverse.com"
            className="inline-block px-8 py-4 bg-white text-blue-600 rounded-full font-semibold hover:bg-gray-100 transition"
          >
            Contact Sales
          </a>
        </div>
      </div>
    </div>
  )
}
