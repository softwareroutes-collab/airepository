'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Search, Menu, X, LogIn, User } from 'lucide-react'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase-client'
import type { User as SupabaseUser } from '@supabase/supabase-js'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [user, setUser] = useState<SupabaseUser | null>(null)
  const pathname = usePathname()
  const supabase = createClient()

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null)
    })

    return () => subscription.unsubscribe()
  }, [])

  const isActive = (path: string) => pathname === path

  return (
    <header className="border-b bg-white sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-blue-600">
            AIverse
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link 
              href="/" 
              className={`hover:text-blue-600 transition ${isActive('/') ? 'text-blue-600 font-semibold' : ''}`}
            >
              Home
            </Link>
            <Link 
              href="/tools" 
              className={`hover:text-blue-600 transition ${isActive('/tools') ? 'text-blue-600 font-semibold' : ''}`}
            >
              Browse Tools
            </Link>
            <Link 
              href="/pricing" 
              className={`hover:text-blue-600 transition ${isActive('/pricing') ? 'text-blue-600 font-semibold' : ''}`}
            >
              Pricing
            </Link>
          </nav>

          {/* User Actions */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <>
                <Link href="/dashboard" className="flex items-center space-x-2 hover:text-blue-600 transition">
                  <User className="h-5 w-5" />
                  <span>Dashboard</span>
                </Link>
                {user.email === 'admin@aiverse.com' && (
                  <Link 
                    href="/admin" 
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
                  >
                    Admin
                  </Link>
                )}
              </>
            ) : (
              <Link 
                href="/login" 
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
              >
                <LogIn className="h-5 w-5" />
                <span>Sign In</span>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 space-y-2 pb-4">
            <Link 
              href="/" 
              className={`block py-2 hover:text-blue-600 transition ${isActive('/') ? 'text-blue-600 font-semibold' : ''}`}
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              href="/tools" 
              className={`block py-2 hover:text-blue-600 transition ${isActive('/tools') ? 'text-blue-600 font-semibold' : ''}`}
              onClick={() => setIsMenuOpen(false)}
            >
              Browse Tools
            </Link>
            <Link 
              href="/pricing" 
              className={`block py-2 hover:text-blue-600 transition ${isActive('/pricing') ? 'text-blue-600 font-semibold' : ''}`}
              onClick={() => setIsMenuOpen(false)}
            >
              Pricing
            </Link>
            {user ? (
              <>
                <Link 
                  href="/dashboard" 
                  className="block py-2 hover:text-blue-600 transition"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Dashboard
                </Link>
                {user.email === 'admin@aiverse.com' && (
                  <Link 
                    href="/admin" 
                    className="block py-2 text-purple-600 hover:text-purple-700 transition"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Admin Panel
                  </Link>
                )}
              </>
            ) : (
              <Link 
                href="/login" 
                className="block py-2 text-blue-600 hover:text-blue-700 transition"
                onClick={() => setIsMenuOpen(false)}
              >
                Sign In
              </Link>
            )}
          </nav>
        )}
      </div>
    </header>
  )
}
