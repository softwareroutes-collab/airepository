# Real API Integration Guide for Scrape-Tools

## Current Implementation

The `scrape-tools` Edge Function currently uses demo data to showcase the automated discovery workflow. This is intentional for ease of deployment and testing.

## Integration with Real Sources

To integrate with real-world APIs, you'll need to obtain API keys and configure the sources. Here's how to enhance the scraping function:

### 1. ProductHunt Integration

**Get API Key**: https://api.producthunt.com/v2/docs

```typescript
// Add to scrape-tools/index.ts
async function scrapeProductHunt(apiKey: string) {
  const query = `
    query {
      posts(first: 20, order: VOTES) {
        edges {
          node {
            name
            tagline
            description
            url
            topics {
              edges {
                node {
                  name
                }
              }
            }
          }
        }
      }
    }
  `

  const response = await fetch('https://api.producthunt.com/v2/api/graphql', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ query })
  })

  const data = await response.json()
  
  return data.data.posts.edges.map((edge: any) => ({
    name: edge.node.name,
    description: edge.node.tagline,
    website_url: edge.node.url,
    tags: edge.node.topics.edges.map((t: any) => t.node.name),
    category_hint: edge.node.topics.edges[0]?.node.name || 'General'
  }))
}
```

### 2. Reddit Integration

**Get API Key**: https://www.reddit.com/prefs/apps

```typescript
async function scrapeReddit(clientId: string, clientSecret: string) {
  // Get access token
  const authResponse = await fetch('https://www.reddit.com/api/v1/access_token', {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials'
  })

  const { access_token } = await authResponse.json()

  // Search AI-related subreddits
  const response = await fetch(
    'https://oauth.reddit.com/r/artificial+MachineLearning/hot.json?limit=50',
    {
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'User-Agent': 'AIverse:v1.0'
      }
    }
  )

  const data = await response.json()
  
  return data.data.children
    .filter((post: any) => post.data.url && !post.data.is_self)
    .map((post: any) => ({
      name: post.data.title,
      description: post.data.selftext || post.data.title,
      website_url: post.data.url,
      tags: ['ai', 'machine-learning'],
      category_hint: 'AI Tools'
    }))
}
```

### 3. GitHub Integration

**Get API Key**: https://github.com/settings/tokens

```typescript
async function scrapeGitHub(token: string) {
  const response = await fetch(
    'https://api.github.com/search/repositories?q=ai+tools+stars:>100&sort=stars&order=desc&per_page=30',
    {
      headers: {
        'Authorization': `token ${token}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    }
  )

  const data = await response.json()
  
  return data.items.map((repo: any) => ({
    name: repo.name,
    description: repo.description,
    website_url: repo.html_url,
    tags: repo.topics || ['opensource', 'github'],
    category_hint: 'Development'
  }))
}
```

### 4. HackerNews Integration

**No API Key Required** - Public API

```typescript
async function scrapeHackerNews() {
  // Get top stories
  const storiesResponse = await fetch(
    'https://hacker-news.firebaseio.com/v0/topstories.json'
  )
  const storyIds = await storiesResponse.json()

  // Get details for first 30 stories
  const stories = await Promise.all(
    storyIds.slice(0, 30).map(async (id: number) => {
      const response = await fetch(
        `https://hacker-news.firebaseio.com/v0/item/${id}.json`
      )
      return response.json()
    })
  )

  // Filter for AI-related tools
  return stories
    .filter((story: any) => 
      story.url && 
      (story.title.toLowerCase().includes('ai') || 
       story.title.toLowerCase().includes('machine learning'))
    )
    .map((story: any) => ({
      name: story.title,
      description: story.title,
      website_url: story.url,
      tags: ['ai', 'hackernews'],
      category_hint: 'AI Tools'
    }))
}
```

## Environment Variables Setup

Add these to your Edge Function secrets:

```bash
# In Supabase Dashboard → Edge Functions → Secrets
PRODUCTHUNT_API_KEY=your_key_here
REDDIT_CLIENT_ID=your_id_here
REDDIT_CLIENT_SECRET=your_secret_here
GITHUB_TOKEN=your_token_here
```

## Updated Main Function

```typescript
// In scrape-tools/index.ts, replace mock data section with:

const productHuntKey = Deno.env.get('PRODUCTHUNT_API_KEY')
const redditId = Deno.env.get('REDDIT_CLIENT_ID')
const redditSecret = Deno.env.get('REDDIT_CLIENT_SECRET')
const githubToken = Deno.env.get('GITHUB_TOKEN')

const allTools = []

// Scrape all sources
if (productHuntKey) {
  const phTools = await scrapeProductHunt(productHuntKey)
  allTools.push(...phTools)
}

if (redditId && redditSecret) {
  const redditTools = await scrapeReddit(redditId, redditSecret)
  allTools.push(...redditTools)
}

if (githubToken) {
  const githubTools = await scrapeGitHub(githubToken)
  allTools.push(...githubTools)
}

// Always scrape HackerNews (no auth required)
const hnTools = await scrapeHackerNews()
allTools.push(...hnTools)

// Process discovered tools...
for (const discoveredTool of allTools) {
  // ... existing deduplication and processing logic
}
```

## Rate Limiting & Best Practices

1. **Respect API Rate Limits**:
   - ProductHunt: 1000 requests/hour
   - Reddit: 60 requests/minute
   - GitHub: 5000 requests/hour (authenticated)

2. **Implement Backoff**:
```typescript
async function fetchWithRetry(url: string, options: any, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch(url, options)
      if (response.status === 429) {
        // Rate limited, wait and retry
        await new Promise(resolve => setTimeout(resolve, 5000 * (i + 1)))
        continue
      }
      return response
    } catch (error) {
      if (i === maxRetries - 1) throw error
    }
  }
}
```

3. **Cache Results**:
   - Store raw API responses temporarily
   - Avoid duplicate API calls within same run

4. **Error Handling**:
   - Log all API errors to scraping_logs
   - Continue processing even if one source fails
   - Send admin notifications for critical failures

## Testing Real Integrations

1. **Get API Keys** from each platform
2. **Add to Edge Function Secrets** in Supabase
3. **Update scrape-tools** function with real implementations
4. **Redeploy** Edge Function
5. **Test** via admin panel manual trigger
6. **Monitor** logs for errors

## Current Demo Data

The current implementation uses demo data that:
- Simulates the complete workflow
- Shows AI processing (deduplication, categorization, summarization)
- Demonstrates the approval process
- Is safe for testing without external API dependencies

## Migration Path

To switch from demo to real data:

1. Obtain API keys (see links above)
2. Add keys to Supabase Edge Function secrets
3. Replace mock data section with real API calls
4. Redeploy the function
5. Test thoroughly before enabling cron job

## Why Demo Data Initially?

- **No External Dependencies**: Works immediately after deployment
- **Cost Control**: No API costs during development/testing
- **Demonstration**: Shows complete workflow without configuration
- **Safety**: Won't accidentally scrape or make API calls

The platform is designed to work perfectly with demo data while making it straightforward to integrate real sources when ready.

---

**Note**: Real API integration is optional. The demo data is sufficient for showcasing the platform's capabilities.
